Puede que hayas visto el archivo manifest.json en este archivo.
manifest.json podría ser necesario para una posterior restauración de una copia de seguridad de este archivo.
Por favor, deja sin tocar manifest.json y en su sitio. De otro modo se ignorará la seguridad.
